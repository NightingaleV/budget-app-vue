<template>
  <div class="home">
    <div>
      <b-jumbotron header="VueBudgetApp">
        <p class="mt-5">Powered by <img width="50" height="50" alt="Vue logo" src="../assets/logo.png"></p>
      </b-jumbotron>
    </div>

  </div>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Home',
  components: {
  }
}
</script>
