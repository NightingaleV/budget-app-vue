import { vuex as accounts } from './accounts';
import { vuex as transactions } from './transactions';
import { vuex as users } from './users';

export default { accounts, transactions, users };