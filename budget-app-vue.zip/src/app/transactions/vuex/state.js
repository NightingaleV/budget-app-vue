const STATE = {
    transactions: null,
    categories: []
};

export default STATE;
