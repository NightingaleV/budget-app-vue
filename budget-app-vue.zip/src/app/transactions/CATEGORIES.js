export const FOOD_DRINKS = 'Food & Drinks';
export const SHOPPING = 'Shopping';
export const HOUSING = 'Housing';
export const TRANSPORTATION = 'Transportation';
export const ENTERTAINMENT = 'Entertainment';
export const TECHNOLOGY = 'Technology';
export const INVESTMENTS = 'Investments';
export const INCOME = 'Income';

// export const CATEGORIES = {
//     food_drinks: {
//         id: '1',
//         title: 'Food & Drinks',
//         icon:'shop'
//     },
//     shopping: {
//         id: '2',
//         title: 'Shopping',
//         icon:'cart'
//     },
//     housing: {
//         id: '3',
//         title: 'Housing',
//         icon:'house-door'
//     },
//     transportation: {
//         id: '4',
//         title: 'Transportation',
//         icon:'truck'
//     },
//     entertainment: {
//         id: '5',
//         title: 'Entertainment',
//         icon:'controller'
//     },
//     technology: {
//         id: '6',
//         title: 'Technology',
//         icon:'laptop'
//     },
//     investments: {
//         id: '7',
//         title: 'Investments',
//         icon:'graph-up'
//     },
//     income: {
//         id: '8',
//         title: 'Income',
//         icon:'table'
//     }
// }

