/** @var { VuexState } */


// import {default as mockup} from '@/../mockup_data'
// const STATE = {
//     accounts: mockup.accounts,
// };

const STATE = {
    accounts: {},
};

export default STATE;
