export { default as AccountsList } from './AccountList/AccountsList.vue';
export { default as CreateUpdateAccount } from './CreateUpdateAccount/CreateUpdateAccount.vue';