export { default as LoginPage } from './LoginPage/LoginPage';
export { default as RegisterPage } from './RegisterPage/RegisterPage';
// export { default as CreateUpdateAccount } from './CreateUpdateAccount/CreateUpdateAccount.vue';