const STATE = {
    user: {email:'', isAuthenticated:false},
};

export default STATE;
